# ContrataDos

## Install

- Instalar Node lts
- Instalar MongoDB
- Bajar la ultima build
- Descomprimir
- Editar .env

**Comandos**.

```bash
# install dependencies
$ npm install --production
$ npm start
```

Ir a [http://localhost:8080/](http://localhost:8080)

## Desarrollo

**Estructura de carpetas**.

**Comandos**.

```bash
# install dependencies
$ npm install

# Run client
$ npm run client

# Run server
$ npm run server

# Run docs
$ npm run docs
```

**Frontend**.

**Backend**.

**Docs**.

Esta escrita en sentencias [Markdown](https://guides.github.com/features/mastering-markdown/)

## Release

**Comandos**.

```bash
# Run build script
$ sh ./release.sh
```
